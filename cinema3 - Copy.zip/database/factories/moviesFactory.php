<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\DaySchedule;
use Faker\Generator as Faker;

$factory->define(DaySchedule::class, function (Faker $faker) {
    return [
        //
    ];
});
