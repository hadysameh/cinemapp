@component('mail::message')
# Introduction

Dear {{$name}} <br>
Your seat number {{$seat_num}} is reserved succesfully



Thanks,<br>
Cinemapp
@endcomponent
