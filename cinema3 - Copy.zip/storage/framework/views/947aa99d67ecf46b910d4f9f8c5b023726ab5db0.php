


<form method="post" action="/tickets">
	<?php echo csrf_field(); ?>
	day
	<input type="date" name="">
	seat_num
	<input type="text" name="seat_num">
	day_schedule_id
	<input type="number" name="day_schedule_id">
	user_id
	<input type="number" name="user_id">
	hall_id
	<input type="number" name="hall_id">
	event_id
	<input type="number" name="event_id">
	movie_id
	<input type="number" name="movie_id">
	<button type="submit">ok</button>
</form><?php /**PATH F:\web courses\projects\cinema3 - Copy\resources\views/test.blade.php ENDPATH**/ ?>