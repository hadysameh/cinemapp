 
<?php $__env->startSection('content'); ?>

<div class="container" style="height: 83vh">
	
	<hall movieid='<?php echo e($movie_id); ?>' moviename='<?php echo e($movie_name); ?>' userid='<?php echo e((auth()->user()) ?auth()->user()->id  : ''); ?>' class='pt-2'></hall>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web courses\projects\cinema3 - Copy\resources\views/seats/seats.blade.php ENDPATH**/ ?>