<?php $__env->startSection('content'); ?>




<section class="jumbotron text-center">
    <div class="container">
      <h1 class="jumbotron-heading">Album example</h1>
      <p class="lead text-muted">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don’t simply skip over it entirely.</p>
      <p>
        <a href="#" class="btn btn-primary my-2">Main call to action</a>
        <a href="#" class="btn btn-secondary my-2">Secondary action</a>
      </p>
    </div>
  </section>


  <div class="album py-5 bg-light">
    <div class="container ">
      <home class='my-3'></home>
      <div class="row justify-content-center">
          
        <div class="px-3">
          <div class="card mb-4 shadow-sm" style="width: 18rem">
            <a href="   ">    
            <img src="https://images-na.ssl-images-amazon.com/images/I/81QVHRQxQXL._SY606_.jpg" class="card-img-top" alt="..."></a>
            <div class="card-body">
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <a  class="btn btn-sm btn-outline-secondary">Buy Ticket</a>
                  <a  class="btn btn-sm btn-outline-secondary">View Details</a>
                </div>
                
              </div>
            </div>
          </div>
        </div>

        <div class="px-3">
          <div class="card mb-4 shadow-sm" style="width: 18rem">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHZhkCLxefHqf_For_hjk5sLUCpXEQNRLxFrhkbc8x0n-5bUxZMw" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">9 mins</small>
              </div>
            </div>
          </div>
        </div>

        <div class="px-3">
          <div class="card mb-4 shadow-sm" style="width: 18rem">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQcMsuao9hNshzYIfQbRTEvI2_rHlQKf9GYD-NNL3aWaeD7rCUm" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">9 mins</small>
              </div>
            </div>
          </div>
        </div>

        <div class="px-3">
          <div class="card mb-4 shadow-sm" style="width: 18rem">
            <img src="https://www.joblo.com/assets/images/joblo/posters/2019/04/avengers_endgame_ver46_xlg.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">9 mins</small>
              </div>
            </div>
          </div>
        </div>

        <div class="px-3">
          <div class="card mb-4 shadow-sm" style="width: 18rem">
            <img src="http://cultureposters.com/wp-content/uploads/2019/04/avengers-2.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">9 mins</small>
              </div>
            </div>
          </div>
        </div>
    </div> 
        </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web courses\projects\cinema3\resources\views/home.blade.php ENDPATH**/ ?>