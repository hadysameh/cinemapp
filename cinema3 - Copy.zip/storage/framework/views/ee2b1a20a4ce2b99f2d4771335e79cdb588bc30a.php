 
<?php $__env->startSection('content'); ?>

<div class="container" style="height: 79vh">
	<h1 class="text-center my-4 ">Hi</h1>
	<p class="text-center h2">this project is to show off my skill set,and what iam cabable of , it fouces more on the back end side</p>
	<br>
	<h2 class="h1">technologies</h2>
	<p class="h2">html5 ,css3 ,javaScript, php laravel , vue JS</p>
	<br>
	<h2 class="h1">Discreption</h2>
	<p class="h2">with this app ,you can can view the current available movies,view taken and available seats in each day and event , you can also book your tickets</p>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web courses\projects\cinema3 - Copy\resources\views/about.blade.php ENDPATH**/ ?>