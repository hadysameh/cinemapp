<?php echo e($slot); ?>

<?php /**PATH F:\web courses\projects\cinema3 - Copy\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>