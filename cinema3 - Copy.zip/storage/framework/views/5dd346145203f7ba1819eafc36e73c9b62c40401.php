<?php $__env->startSection('content'); ?>




<section class="jumbotron text-center my-2" >
    <div class="container my-3">
      <h1 class="jumbotron-heading">Cinema App</h1>
      <p class="lead text-muted "><h3 class="text-secondary">Welocme , to our cinema booking app , you can view available movies , view available seats , and buy tickets for any movie you want</h3></p>
      <p>
        <a id='vi' href="#movies" class="btn btn-primary my-2">View Movies</a>
      </p>
    </div>
  </section>



  <div id='movies' class="album py-5 bg-light">
    <div class="container ">
    <home today='<?php echo e($today); ?>' tom='<?php echo e($tomorrow); ?>' after='<?php echo e($aftertom); ?>' date='<?php echo e($day_link); ?>' class='my-3'></home>

      <div class="row justify-content-center">
          
          <?php $__currentLoopData = $daySchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daySchedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                         
              <div class="px-3">
                <div class="card mb-4 shadow-sm" style="width: 18rem">
                  <a href="/details/<?php echo e($daySchedule->movie->id); ?>">    
                  <img src="/storage/<?php echo e($daySchedule->movie->image); ?>" class="card-img-top" alt="..." style="height: 27rem"></a>
                  <div class="card-body">
                    
                    <h4><?php echo e($daySchedule->movie->movie_name); ?></h4>
                    <p class="card-text">
                      <div class="d-flex align-items-baseline">
                        <h5>length</h5>:<?php echo e($daySchedule->movie->length); ?>

                      </div>
                    </p>
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="btn-group">
                        <a href="/tickets/<?php echo e($daySchedule->movie->id); ?>" class="btn btn-sm btn-outline-secondary">View Seats</a>
                        <a href="/details/<?php echo e($daySchedule->movie->id); ?>"  class="btn btn-sm btn-outline-secondary">View Details</a>
                      </div>
                      
                    </div>
                  </div>
                </div>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
      </div>

          <div class="d-flex justify-content-center">
            <?php echo e($daySchedules->links()); ?>

          </div>

<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web courses\projects\cinema3 - Copy\resources\views/movies/home.blade.php ENDPATH**/ ?>