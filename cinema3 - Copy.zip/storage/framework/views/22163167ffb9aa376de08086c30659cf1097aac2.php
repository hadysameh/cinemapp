<?php $__env->startSection('content'); ?>

<div class="container" style="height: 76vh">
	<div class="row my-5">
		<div class="col-lg-4 justify-content-center">
						

			<div class="d-flex justify-content-center" >

				<img style="width: 18rem;height: 27rem" src="/storage/<?php echo e($movie_details[0]->movie->image); ?>">
			</div>
		</div>
		

		<div class="col-lg-8 pt-3">
			<h2 class="text-center"><?php echo e($movie_details[0]->movie->movie_name); ?></h2>
			
			<h5 class="text-center">available parties</h5>
			<table class="table text-center">
			  <thead>
			    <tr>
			      <th scope="col">#</th>
			      <th scope="col">Day</th>
			      <th scope="col">Time</th>
			      
			    </tr>
			  </thead>
			  <tbody>
			  	<?php $i=0; ?>
			  	<?php $__currentLoopData = $movie_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			    <tr>
			      <th scope="row"><?php echo e(++$i); ?></th>
			      <td><?php echo e($movie_detail->day); ?></td>
			      <td><?php echo e($movie_detail->event->event_time); ?></td>
			      
			    </tr>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			   
			  </tbody>
			</table>
			<div class="text-center">
				<a href="/tickets/<?php echo e($movie_details[0]->movie->id); ?>" class="btn btn-success">get tickets</a>
			</div>
	</div>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web courses\projects\cinema3 - Copy\resources\views/movies/details.blade.php ENDPATH**/ ?>