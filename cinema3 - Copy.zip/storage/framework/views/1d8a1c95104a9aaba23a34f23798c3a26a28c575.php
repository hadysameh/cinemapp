<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row my-5">
		<div class="col-lg-4 justify-content-center">
						

			<div class="d-flex justify-content-center" >

				<img style="width: 18rem;height: 27rem" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHZhkCLxefHqf_For_hjk5sLUCpXEQNRLxFrhkbc8x0n-5bUxZMw">
			</div>
		</div>
		

		<div class="col-lg-8 pt-3">
			<h2 class="text-center">movie name</h2>
			
			<h5 class="text-center">available parties</h5>
			<table class="table text-center">
			  <thead>
			    <tr>
			      <th scope="col">#</th>
			      <th scope="col">First</th>
			      <th scope="col">Last</th>
			      
			    </tr>
			  </thead>
			  <tbody>
			    <tr>
			      <th scope="row">1</th>
			      <td>Mark</td>
			      <td>Otto</td>
			      
			    </tr>
			    <tr>
			      <th scope="row">2</th>
			      <td>Jacob</td>
			      <td>Thornton</td>
			      
			    </tr>
			    <tr>
			      <th scope="row">3</th>
			      <td>Larry</td>
			      <td>the Bird</td>
			      
			    </tr>
			  </tbody>
			</table>
			<div class="text-center">
				<date></date>
			</div>
	</div>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web courses\projects\cinema3\resources\views/movies/details.blade.php ENDPATH**/ ?>