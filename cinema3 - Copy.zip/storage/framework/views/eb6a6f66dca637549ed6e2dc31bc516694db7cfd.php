<?php $__env->startComponent('mail::message'); ?>
# Introduction

Dear <?php echo e($name); ?> <br>
Your seat number <?php echo e($seat_num); ?> is reserved succesfully



Thanks,<br>
Cinemapp
<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\web courses\projects\cinema3 - Copy\resources\views/emails/taken-seats.blade.php ENDPATH**/ ?>